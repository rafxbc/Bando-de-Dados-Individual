--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trabalho_individual;
--
-- Name: trabalho_individual; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trabalho_individual WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE trabalho_individual OWNER TO postgres;

\connect trabalho_individual

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: delegacia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delegacia (
    del_cd_id integer NOT NULL,
    del_tx_nome character varying(50) NOT NULL,
    del_tx_hrinicio character varying(5) NOT NULL,
    del_tx_hrfim character varying(5) NOT NULL,
    del_fk_end integer NOT NULL
);


ALTER TABLE public.delegacia OWNER TO postgres;

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delegacia_del_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delegacia_del_cd_id_seq OWNER TO postgres;

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delegacia_del_cd_id_seq OWNED BY public.delegacia.del_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_cep character varying(10) NOT NULL,
    end_tx_bairro character varying(20) NOT NULL,
    end_tx_num integer NOT NULL
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: investigacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investigacao (
    in_fk_rg integer NOT NULL,
    in_fk_pro integer NOT NULL,
    in_fk_del integer NOT NULL
);


ALTER TABLE public.investigacao OWNER TO postgres;

--
-- Name: profissional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profissional (
    pro_cd_id integer NOT NULL,
    pro_tx_nome character varying(30) NOT NULL,
    pro_tx_funcao character varying(30) NOT NULL,
    pro_int_idade integer NOT NULL
);


ALTER TABLE public.profissional OWNER TO postgres;

--
-- Name: profissional_pro_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profissional_pro_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profissional_pro_cd_id_seq OWNER TO postgres;

--
-- Name: profissional_pro_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profissional_pro_cd_id_seq OWNED BY public.profissional.pro_cd_id;


--
-- Name: registro_denuncia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registro_denuncia (
    rd_cd_id integer NOT NULL,
    rd_tx_ocorrencia character varying(30) NOT NULL,
    rd_tx_nome_vitima character varying(20),
    rd_int_idade_vitima integer,
    rd_tx_horario_oc character varying(5) NOT NULL,
    rd_fk_end integer NOT NULL
);


ALTER TABLE public.registro_denuncia OWNER TO postgres;

--
-- Name: registro_denuncia_rd_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registro_denuncia_rd_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registro_denuncia_rd_cd_id_seq OWNER TO postgres;

--
-- Name: registro_denuncia_rd_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registro_denuncia_rd_cd_id_seq OWNED BY public.registro_denuncia.rd_cd_id;


--
-- Name: delegacia del_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia ALTER COLUMN del_cd_id SET DEFAULT nextval('public.delegacia_del_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: profissional pro_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profissional ALTER COLUMN pro_cd_id SET DEFAULT nextval('public.profissional_pro_cd_id_seq'::regclass);


--
-- Name: registro_denuncia rd_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_denuncia ALTER COLUMN rd_cd_id SET DEFAULT nextval('public.registro_denuncia_rd_cd_id_seq'::regclass);


--
-- Data for Name: delegacia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delegacia (del_cd_id, del_tx_nome, del_tx_hrinicio, del_tx_hrfim, del_fk_end) FROM stdin;
\.
COPY public.delegacia (del_cd_id, del_tx_nome, del_tx_hrinicio, del_tx_hrfim, del_fk_end) FROM '$$PATH$$/4818.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_cd_id, end_tx_cep, end_tx_bairro, end_tx_num) FROM stdin;
\.
COPY public.endereco (end_cd_id, end_tx_cep, end_tx_bairro, end_tx_num) FROM '$$PATH$$/4814.dat';

--
-- Data for Name: investigacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investigacao (in_fk_rg, in_fk_pro, in_fk_del) FROM stdin;
\.
COPY public.investigacao (in_fk_rg, in_fk_pro, in_fk_del) FROM '$$PATH$$/4821.dat';

--
-- Data for Name: profissional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profissional (pro_cd_id, pro_tx_nome, pro_tx_funcao, pro_int_idade) FROM stdin;
\.
COPY public.profissional (pro_cd_id, pro_tx_nome, pro_tx_funcao, pro_int_idade) FROM '$$PATH$$/4816.dat';

--
-- Data for Name: registro_denuncia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registro_denuncia (rd_cd_id, rd_tx_ocorrencia, rd_tx_nome_vitima, rd_int_idade_vitima, rd_tx_horario_oc, rd_fk_end) FROM stdin;
\.
COPY public.registro_denuncia (rd_cd_id, rd_tx_ocorrencia, rd_tx_nome_vitima, rd_int_idade_vitima, rd_tx_horario_oc, rd_fk_end) FROM '$$PATH$$/4820.dat';

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delegacia_del_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 10, true);


--
-- Name: profissional_pro_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profissional_pro_cd_id_seq', 5, true);


--
-- Name: registro_denuncia_rd_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registro_denuncia_rd_cd_id_seq', 5, true);


--
-- Name: delegacia delegacia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia
    ADD CONSTRAINT delegacia_pkey PRIMARY KEY (del_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: profissional profissional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profissional
    ADD CONSTRAINT profissional_pkey PRIMARY KEY (pro_cd_id);


--
-- Name: registro_denuncia registro_denuncia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_denuncia
    ADD CONSTRAINT registro_denuncia_pkey PRIMARY KEY (rd_cd_id);


--
-- Name: delegacia delegacia_del_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia
    ADD CONSTRAINT delegacia_del_fk_end_fkey FOREIGN KEY (del_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- Name: investigacao investigacao_in_fk_del_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigacao
    ADD CONSTRAINT investigacao_in_fk_del_fkey FOREIGN KEY (in_fk_del) REFERENCES public.delegacia(del_cd_id);


--
-- Name: investigacao investigacao_in_fk_pro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigacao
    ADD CONSTRAINT investigacao_in_fk_pro_fkey FOREIGN KEY (in_fk_pro) REFERENCES public.profissional(pro_cd_id);


--
-- Name: investigacao investigacao_in_fk_rg_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigacao
    ADD CONSTRAINT investigacao_in_fk_rg_fkey FOREIGN KEY (in_fk_rg) REFERENCES public.registro_denuncia(rd_cd_id);


--
-- Name: registro_denuncia registro_denuncia_rd_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_denuncia
    ADD CONSTRAINT registro_denuncia_rd_fk_end_fkey FOREIGN KEY (rd_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- PostgreSQL database dump complete
--

